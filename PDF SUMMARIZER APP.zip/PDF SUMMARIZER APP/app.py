from dotenv import load_dotenv
import streamlit as st
import os
import textwrap
import google.generativeai as genai
import fitz

load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

def to_markdown(text):
    text = text.replace('•', '  *')
    return textwrap.indent(text, '> ', predicate=lambda _: True)

def get_gemini_response(prompt):
    model = genai.GenerativeModel('gemini-pro')
    response = model.generate_content(prompt)
    return response.text

def extract_text_from_pdf(pdf_file):
    text = ""
    with fitz.open(stream=pdf_file.read(), filetype="pdf") as doc:
        for page in doc:
            text += page.get_text()
    return text

def summarize_to_points(text):
    points_prompt = f"Please summarize the following text into bullet points:\n\n{text}"
    points = get_gemini_response(points_prompt)
    return points

def ask_question_about_pdf(pdf_text, question):
    question_prompt = f"The following text is from the PDF document:\n\n{pdf_text}\n\nAnswer the following question based on the text: {question}"
    answer = get_gemini_response(question_prompt)
    return answer

st.set_page_config(page_title="PDF Summarizer and Q&A", page_icon="📄")

# Add CSS for background, white text, and dark blue button
st.markdown(
    """
    <style>
        body {
            background-image: url('https://wallpaperaccess.com/full/210888.jpg');
            background-size: cover;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
            color: white; /* Set all text to white */
        }
        .stApp {
            background: transparent;
            color: white; /* Ensures Streamlit widgets also inherit white text */
        }
        h1, h2, h3, h4, h5, h6, p, div, span, label {
            color: white !important; /* Make all text elements white */
        }
        .stButton > button {
            background-color: #003366; /* Dark Blue */
            color: white; /* White text on the button */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        .stButton > button:hover {
            background-color: #002244; /* Slightly darker blue on hover */
        }
    </style>
    """,
    unsafe_allow_html=True
)

st.title("PDF Summarizer and Q&A")
st.markdown("---")

if 'summarized_points' not in st.session_state:
    st.session_state.summarized_points = ""
if 'history' not in st.session_state:
    st.session_state.history = []

uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])

if uploaded_file:
    pdf_text = extract_text_from_pdf(uploaded_file)
    summarized_points = summarize_to_points(pdf_text)
    st.session_state.summarized_points = summarized_points

    st.subheader("Summarized Points")
    st.markdown(to_markdown(summarized_points))

    question = st.text_input("Enter your question about the PDF:", key="question")

    # Add the "Ask the question" button styled in dark blue
    if st.button("Ask the question") and question:
        answer = ask_question_about_pdf(pdf_text, question)
        st.subheader("Answer")
        st.markdown(answer)
        st.session_state.history.append((question, answer))

if st.session_state.history:
    st.markdown("---")
    st.subheader("History")
    for i, (q, a) in enumerate(st.session_state.history):
        st.markdown(f"**Q{i+1}:** {q}")
        st.markdown(f"**A{i+1}:** {a}")
        st.markdown("---")
